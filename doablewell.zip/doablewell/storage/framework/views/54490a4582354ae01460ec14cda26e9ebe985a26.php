<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css" rel="stylesheet"/>
<body>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container" style="width: 65%;"><br>
<h2><?php echo e($title); ?></h2>
<form method="POST" action="<?php echo e(url('admin/update_link')); ?>">
  <?php echo csrf_field(); ?>
  <div class="form-row">
      <input type="hidden" value="<?php echo e($link->id); ?>" name="id" />
    <div class="form-group col-md-12">
      <label for="inputEmail4">category</label>
     
      <select class="form-control" id="" name="category">
         <option value="<?php echo e($link->category_id); ?>">Select category</option>
         <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->category_name); ?></option>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
    <div class="form-group col-md-12">
      <label for="inputPassword4">Title</label>
      <input type="text" class="form-control" name="link_title" value="<?php echo e($link->title); ?>" >
    </div>
  </div>
  <div class="form-group col-md-12">
    <label for="inputAddress">Description</label>
    <textarea type="text" class="form-control" name="description" id="inputAddress"><?php echo e($link->description); ?></textarea>
  </div>
  <div class="form-group col-md-12">
    <label for="inputAddress2">Youtube Link</label>
    <input type="text" class="form-control" id="inputAddress2" name="link" value="<?php echo e($link->youtube_link); ?>">
  </div>
  
  
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script><?php /**PATH C:\xampp\htdocs\doable-wellness-backend\resources\views/Admin/edit_link.blade.php ENDPATH**/ ?>