<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css" rel="stylesheet"/>
<body>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container" style="width: 65%;"><br>
<h2><?php echo e($title); ?></h2>
<?php if(Session::has('success')): ?>

<div class="alert alert-success" style="color: #8ec48e;"><?php echo e(Session::get('success')); ?></div>

<?php endif; ?>

<?php if(Session::has('warning')): ?>

<div class="alert alert-danger"><?php echo e(Session::get('warning')); ?></div>

<?php endif; ?>
<form method="POST" action="#">
  <?php echo csrf_field(); ?>
  <div class="form-row">
      <input type="hidden" value="<?php echo e($category->id); ?>" name="id" />
    <div class="form-group col-md-12">
    <label for="inputPassword4">Category Name</label>
      <input type="text" class="form-control" name="category_name" value="<?php echo e($category->category_name); ?>" readonly>
    </div>
    <div class="form-group col-md-12">
    <label for="inputPassword4">Category Description</label>
      <textarea type="text" class="form-control" name="description" readonly><?php echo e($category->description); ?></textarea>
    </div>
   
  </div>
 
  
</form>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script><?php /**PATH C:\xampp\htdocs\doable-wellness-backend\resources\views/Admin/category/view.blade.php ENDPATH**/ ?>