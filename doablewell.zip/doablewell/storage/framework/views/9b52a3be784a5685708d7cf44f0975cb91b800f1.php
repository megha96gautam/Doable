<!DOCTYPE html>
<html>
<head>
   
</head>
<body>
   
   
    <p>Hi Admin</p>
    <p>This <?php echo e($username); ?> send reword request please proceed for reword points.</p>
</body>
</html><?php /**PATH C:\xampp\htdocs\doable-wellness-backend\resources\views/reword_request.blade.php ENDPATH**/ ?>