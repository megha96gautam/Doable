<!DOCTYPE html>
<html>
<head>
   
</head>
<body>
   
   
    <p>Hi </p>
    <p>Your Doablewellness forgot password otp is <?php echo e($otp); ?>.</p>
</body>
</html><?php /**PATH C:\xampp\htdocs\doable-wellness-backend\resources\views/emailOtp.blade.php ENDPATH**/ ?>