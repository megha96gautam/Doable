<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css" rel="stylesheet"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<body>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div  style="width: 95%;margin-bottom:70px">
<a type="button" href="<?php echo e(url('admin/add_link')); ?>" class="btn btn-info" style="float:right;">Add link</a>
</div>
<div class="container" style="width: 95%;"><br>
<?php if(Session::has('success')): ?>

<div class="alert alert-success" style="color: #8ec48e;"><?php echo e(Session::get('success')); ?></div>

<?php endif; ?>

<?php if(Session::has('warning')): ?>

<div class="alert alert-danger"><?php echo e(Session::get('warning')); ?></div>

<?php endif; ?>
<div class="col-lg-12">
<table id="example" style="    margin-top: 80px;" class="display" style="width:100%">
        <thead>
            <tr>
                <th>SNo.</th>
                <th>Slider Group</th>
                <th>Title</th>
                <th>Youtube Link</th>
                <th>Text</th>
                <th>Thumbnails</th>
                <th>create_at</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
          <?php   $i= 1; ?>
        <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo $i++; ?></td>
                <td><?php echo e($link->category_id); ?></td>
                <td><?php echo e($link->title); ?></td>
                <td><?php echo e($link->youtube_link); ?></td>
                <td><?php echo e($link->description); ?></td>
                <td><img width="100px" height="100px" src="<?php echo e(url('youtube_img')); ?>/<?php echo e($link->thumbnails); ?>" /> </td>
                <td><?php echo e($link->created_at); ?></td>
                <td>
                    <a type="button" class="btn btn-warning" href="<?php echo e(url('admin/view_link/'.$link->id)); ?>" ><i class="fa fa-reply" style="font-size:12px"></i></a>
                 
                    <a type="button" class="btn btn-info" href="<?php echo e(url('admin/edit_link/'.$link->id)); ?>">
                        <i class="fa fa-edit" style="font-size:12px"></i></a> 
                    <a  type="button" onclick="return confirm('Are you sure you want to delete this link?');" class="btn btn-danger" href="<?php echo e(url('admin/link_delete/'.$link->id)); ?>"><i class="fa fa-trash-o" style="font-size:12px"></i></a>
                   
                </td>
            </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </tbody>
        <!-- <tfoot>
            <tr>
                <th>Name</th>
                <th>Position</th>
                <th>Office</th>
                <th>Age</th>
                <th>Start date</th>
                <th>Salary</th>
            </tr>
        </tfoot> -->
    </table>
</div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script>
  $(document).ready(function() {
    $('#example').DataTable();
} );
</script><?php /**PATH C:\xampp\htdocs\doable-wellness-backend\resources\views/Admin/dashboard.blade.php ENDPATH**/ ?>