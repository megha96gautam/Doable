<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css" rel="stylesheet"/>
<body>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container" style="width: 65%;"><br>
<h2><?php echo e($title); ?></h2>
<form method="POST" action="<?php echo e(url('admin/create_link')); ?>">
  <?php echo csrf_field(); ?>
  <div class="form-row">
    <div class="form-group col-md-12">
      <label for="inputEmail4">Category</label>
     
      <select class="form-control" id="" name="category" required>
         <option>Select category</option>
         <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->category_name); ?></option>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
    <div class="form-group col-md-12">
      <label for="inputPassword4">Title</label>
      <input type="text" class="form-control" name="link_title" id="inputPassword4" required>
    </div>
  </div>
  <div class="form-group col-md-12">
    <label for="inputAddress">Description</label>
    <textarea type="text" class="form-control" name="description" id="inputAddress" ></textarea>
  </div>
  <div class="form-group col-md-12">
    <label for="inputAddress2">Youtube Link</label>
    <input type="text" class="form-control" id="inputAddress2" name="link">
  </div>
  
  <div class="form-group col-md-12">
  <button type="submit" class="btn btn-primary">Submit</button>
</div>
</form>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script><?php /**PATH C:\xampp\htdocs\doable-wellness-backend\resources\views/Admin/add_link.blade.php ENDPATH**/ ?>