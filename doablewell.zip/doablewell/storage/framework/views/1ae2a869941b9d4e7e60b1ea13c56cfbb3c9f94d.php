<style>
  .float-right{
    float:right;
  }
</style>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="<?php echo e(url('admin/users')); ?>">Doable Wellness</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="<?php echo e((Request::segment(2) == 'users' ) ? 'active' : ''); ?>"><a href="<?php echo e(url('admin/users')); ?>">User List</a></li>
      <li class="<?php echo e((Request::segment(2) == 'category' ) ? 'active' : ''); ?>"><a href="<?php echo e(url('admin/category')); ?>">Category List</a></li>
      <li class="<?php echo e((Request::segment(2) == 'dashboard' ) ? 'active' : ''); ?>"><a href="<?php echo e(url('admin/dashboard')); ?>">Youtube Link List</a></li>
      <li class="<?php echo e((Request::segment(2) == 'profile' ) ? 'active' : ''); ?>"><a href="<?php echo e(url('admin/profile')); ?>">Profile</a></li>
      <li class="<?php echo e((Request::segment(2) == 'reset_password' ) ? 'active' : ''); ?>"><a href="<?php echo e(url('admin/reset_password')); ?>">Reset Password</a></li>
     
    </ul>
    <ul class="nav navbar-nav" style="float:right">
    <li class="nav-item dropdown"  >
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <?php echo e(Auth::user()->username); ?>

        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="<?php echo e(url('admin/logout')); ?>">Logout</a>
        
        </div>
      </li>
    </ul>
  
   
  </div>
</nav><?php /**PATH C:\xampp\htdocs\doable-wellness-backend\resources\views/layouts/nav.blade.php ENDPATH**/ ?>