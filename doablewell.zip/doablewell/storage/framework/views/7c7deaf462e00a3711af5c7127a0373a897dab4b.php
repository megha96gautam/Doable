<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css" rel="stylesheet"/>
<body>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container" style="width: 65%;"><br>
<h2><?php echo e($title); ?></h2>
<form method="POST" action="#">
  <?php echo csrf_field(); ?>
  <div class="form-row">
      <input type="hidden" value="<?php echo e($link->id); ?>" name="id" />
    <div class="form-group col-md-12">
      <label for="inputEmail4">Title</label>
     
      <input class="form-control" value="<?php echo e($link->title); ?>" name="category">
       
    </div>
    <div class="form-group col-md-12">
      <label for="inputPassword4">youtube_link</label>
      <input type="text" class="form-control" name="link_title" value="<?php echo e($link->youtube_link); ?>" >
    </div>
  </div>
  <div class="form-group col-md-12">
    <label for="inputAddress">Description</label>
    <input type="text" class="form-control" name="description" value="<?php echo e($link->description); ?>"/>
  </div>

  
  
  <!-- <button type="submit" class="btn btn-primary">Submit</button> -->
</form>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script><?php /**PATH C:\xampp\htdocs\doable-wellness-backend\resources\views/Admin/links/view.blade.php ENDPATH**/ ?>