<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;

use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\category;
use App\Models\youtube_link;
use Storage;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon as Time;
class DashboardController extends Controller

{
    public function __construct(){
        $this->middleware('auth');
    }

    public function dashboard(){
         $links = youtube_link::select('tbl_youtube_video_link.*','tbl_category.category_name')
         ->leftJoin('tbl_category', 'tbl_youtube_video_link.category_id', '=', 'tbl_category.id')
         ->orderBy('tbl_youtube_video_link.id', 'desc')
         ->where('tbl_youtube_video_link.status_delete','1')
         ->get();
       // dd(Auth::user()->username);
         return view('Admin.dashboard',[
          'title' => 'Admin Dashboard',
          'page'  => 'dashboard',
          'links'  => $links,

      ]);
  }


  
  public function user_list(){
    $user = User::where('user_deleted','1')->get();


    return view('Admin.user',[
      'title' => 'User List',
      'users'  => $user,

  ]);
  }

  public function profile(){
    
      return view('Admin.profile',[
        'title' => 'Admin Profile',
    ]);
  }
  public function update_profile(Request $request){
   
        $user = User::where('id',$request->id)->first();
        $user->username = $request->username;
        $user->company_name = $request->company_name;
        $user->save();
          if($user){
          return redirect('admin/profile')->with('success', 'Admin Updated successfully.');
          }else{
          return redirect('/login')->with('warning', 'Admin not applicable.');
        }
   }
   public function reset_password(){
    return view('Admin.reset_password',[
      'title' => 'Admin Reset Password ',
  ]);
   }

  public function update_password(Request $request){
    $user = User::where('id', '1')->first();
    $HashedPass = $user->password;
    if(Hash::check($request->old_pass, $HashedPass))   
    {
      if( $request->confm_pass == $request->new_pass){
        $user->password = bcrypt($request->new_pass);
        $user->save();
        return redirect('admin/reset_password')->with('success', 'Password Change Successfully ');
        }else{
          return redirect('admin/reset_password')->with('warning', 'New password and Confirm Password Not matched');
        }
    }
    else{
      return redirect('admin/reset_password')->with('warning', 'Old Password Not Correct');
    }
     
  }

}
