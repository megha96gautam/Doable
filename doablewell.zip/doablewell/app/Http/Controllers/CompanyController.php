<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
class CompanyController extends Controller
{
    public function __construct(){
        $this->middleware('auth');
    }

    public function list(){
        $links = youtube_link::select('tbl_youtube_video_link.*','tbl_category.category_name')
        ->leftJoin('tbl_category', 'tbl_youtube_video_link.category_id', '=', 'tbl_category.id')
        ->where('tbl_youtube_video_link.status_delete','0')
        ->orderBy('tbl_youtube_video_link.id', 'desc')
        ->get();
      // dd(Auth::user()->username);
        return view('Admin.dashboard',[
         'title' => 'Admin Dashboard',
         'page'  => 'dashboard',
         'links'  => $links,

     ]);
 }

    public function add_company(){
      
        return view('Admin.Company.add',[
          'title' => 'Add Company',
         
      ]);
      }
}

