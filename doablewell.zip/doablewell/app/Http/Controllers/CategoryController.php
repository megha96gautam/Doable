<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\category;

class CategoryController extends Controller
{
    public function __construct(){
        $this->middleware('auth');
    }

    public function category_list(){
        $category = category::where('status_delete','1')->orderBy('id', 'desc')
        ->get();
      // dd(Auth::user()->username);
        return view('Admin.category.list',[
         'title' => 'Admin Category',
         'page'  => 'Category',
         'category'  => $category,

     ]);
 }

    public function add_category(){
      
        return view('Admin.category.add',[
          'title' => 'Add Category',
        
      ]);
      }

   public function edit_category(Request $request){
       // echo $request->id;
        $category = Category::where('id', $request->id)->first();
     
        return view('Admin.category.edit',[
          'title' => 'Edit Category',
          'category' =>$category,
         
      ]);
    
      }
      public function view_category(Request $request){
       
      
        $category = category::where('id', $request->id)->first();
        return view('Admin.category.view',[
          'title' => 'View category',
          'category' =>$category
      ]);
    
      }
 
      public function category_delete($id){
          
           $link = category::where('id', $id)->first();
          // dd($link);
           $link->status_delete ='0';
           $link->save();
           return redirect('admin/category')->with('success', 'category Deleted successfully.');
        
      }
  public function submit_category(Request $request){
   
  

   $cate = new Category;
   $cate->category_name = $request->category_name;
   $cate->description = $request->description;
   $cate->active_status = '1';
   $cate->save();
   if($cate->id){
   return redirect('admin/category')->with('success', 'Category Added successfully.');
   }else{
   return redirect('/login')->with('warning', 'User not applicable.');
  }
 }

  public function update_category(Request $request){
   $linkdb = Category::where('id', $request->id)->first();
  
       $linkdb->category_name = $request->category_name;
       $linkdb->description = $request->description;
       $linkdb->active_status = '1';
       $linkdb->save();
         if($linkdb->id){
         return redirect('admin/category')->with('success', 'Category Updated successfully.');
         }else{
         return redirect('/login')->with('warning', 'User not applicable.');
       }
  }
}
