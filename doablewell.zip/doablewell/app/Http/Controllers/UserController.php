<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;

use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\category;
use App\Models\youtube_link;
use App\Models\Notification;
use Storage;
use Carbon\Carbon as Time;
class UserController extends Controller

{
    public function __construct(){
        $this->middleware('auth');
    }

    public function add_user(){
     
      return view('Admin.add_user',[
        'title' => 'Add User'
  
    ]);
    }
    public function delete($id){
          
        $link = User::where('id', $id)->first();
       // dd($link);
        $link->user_deleted ='0';
        $link->save();
        return redirect('admin/users')->with('success', 'User Deleted successfully.');
     
   }
   public function view_user(Request $request){
    //echo $request->id;
    $user = User::where('id', $request->id)->first();
    return view('Admin.links.view',[
      'title' => 'User View',
      'user'  => $user,

  ]);

  }

  public function edit_user(Request $request){
   // echo $request->id;
    $user = User::where('id', $request->id)->first();
    
    return view('Admin.user_edit',[
      'title' => 'Edit User',
      'user'  => $user,

  ]);

  }
  public function update_user(Request $request){
   
    $user = User::where('id',$request->id)->first();
        $user->username = $request->username;
        $user->company_name = $request->company_name;
        $user->save();
          if($user){
          return redirect('admin/users')->with('success', 'User Updated successfully.');
          }else{
          return redirect('/login')->with('warning', 'User not applicable.');
        }
   }
   public function checkemail(Request $request)
    {
      $email = $request->email;
      $emailcheck = User::where('email',$email)->count();
      if($emailcheck > 0)
      {
      echo "Email Already In Use.";
      }
    }

   public function create_user(Request $request){
   
    
    $linkdb = new User;
    $linkdb->username = $request->username;
    $linkdb->company_name = $request->company_name;
    $linkdb->email =  $request->email;
    $linkdb->password = bcrypt($request->password);
    $linkdb->user_role = "0";
    $linkdb->save();
    if($linkdb->id){
    return redirect('admin/users')->with('success', 'User Added successfully.');
    }else{
    return redirect('admin/users')->with('warning', 'User not register try again.');
   }
  }

  
  public function send_notification(Request $request)
  {  
    $user= User::where('id', $request->id)->first();
    $user->notify_token;
    $user_token= $user->notify_token; // Token generated from Android device after setting up firebase
   // $user_token="cnFKgnhcrUUli3InqfUzUC:APA91bGMbppu1Y8rNeti9mIOXgZ2DiH3pN_H_yewx5EPANxEPvByjZrbxeQUtkAlDSVX6S-ms4nw19K_lyz0a0EPn7h6yCRtSLlhHv_1MVdKfTITgLn5SdCwhVld61xO6ejMCFCWtSZe"; // Token generated from Android device after setting up firebase
    $title="Doable Wellness";
    $n_msg="Hi, You get Reword Points please check";
          //branded
          $server_key="AAAA5EkqgsI:APA91bGMBhH-3EWjx8G1yRgrmEeRwrqTQ1vIDH_LgWlbo2ih2W_yxc70oZS3Rjg-prXEdcn-0xaQh-EqmpqGBuHj6afJ1TPuHmZXWIgZKTz0sal0TceR9UTZcUwOeKdiadhF-WWZAb67"; // get this from Firebase project settings->Cloud Messaging

        //  $push_notification_key = 'AAAABAXk454:APA91bE-yZhQw9fa35mFDSNYp_c4ENcxFZuMD7FHum40vY4JuzQoxNBahvcbXR6B4IdYm065Qrr8Ys9eMXgVHkatgTGZ1PAKOyZiF0wP7eU0gMTh-AZShEcbUyP0S2LjhlpKg98W07xN';
          $sound = "default";
    
      // return "success";
      // return $fcm_token;
    if($user_token != null){  
      $registration_ids = [];
      if(!empty($user_token)){            
          $registration_ids = explode(',', $user_token);
      }

      $url = "https://fcm.googleapis.com/fcm/send";
      // $global_order = GlobalOrder::find($global_order_id);
      $data = [
          "registration_ids" => $registration_ids, // Multiple Token
          // 'to' => $fcm_token, // Single
          "notification" => [
              "title" => $title,
              "body" => "Doable",
              "sound" => $sound,
          ],
          "data" => [
              "message" => $n_msg,
          ],
      ];
      $postdata = json_encode($data);
      $header = [
          'Authorization: key=' . $server_key,
          'Content-Type: application/json',
      ];

      $ch = curl_init();
      $timeout = 120;
      curl_setopt($ch, CURLOPT_URL, $url);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
      curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
      curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
      curl_setopt($ch, CURLOPT_HTTPHEADER, $header);

      // Get URL content
      $result = curl_exec($ch);
      if ($result === FALSE) {
        die('FCM Send Error: ' . curl_error($ch));
    }
      curl_close($ch);
  }
     // return $result;


    
    $post = new Notification;
    $post->user_id = $request->id;
    $post->title =  $title;
    $post->description =  $n_msg;
    $post->notify_date = Time::now()->timestamp;
    $post->save();
    return redirect('admin/users')->with('success', 'Sent Notification successfully.');
   
  }
 

  public function claimpoints(Request $request)
  {  
 
    $user= User::where('id', $request->id)->first();
    $user->notify_token;
    $user_token= $user->notify_token; // Token generated from Android device after setting up firebase
   // $user_token="cnFKgnhcrUUli3InqfUzUC:APA91bGMbppu1Y8rNeti9mIOXgZ2DiH3pN_H_yewx5EPANxEPvByjZrbxeQUtkAlDSVX6S-ms4nw19K_lyz0a0EPn7h6yCRtSLlhHv_1MVdKfTITgLn5SdCwhVld61xO6ejMCFCWtSZe"; // Token generated from Android device after setting up firebase
    $title="Doable Wellness";
    $n_msg="Hi, Claim your Points";

          //branded
          $server_key="AAAA5EkqgsI:APA91bGMBhH-3EWjx8G1yRgrmEeRwrqTQ1vIDH_LgWlbo2ih2W_yxc70oZS3Rjg-prXEdcn-0xaQh-EqmpqGBuHj6afJ1TPuHmZXWIgZKTz0sal0TceR9UTZcUwOeKdiadhF-WWZAb67"; // get this from Firebase project settings->Cloud Messaging

        //  $push_notification_key = 'AAAABAXk454:APA91bE-yZhQw9fa35mFDSNYp_c4ENcxFZuMD7FHum40vY4JuzQoxNBahvcbXR6B4IdYm065Qrr8Ys9eMXgVHkatgTGZ1PAKOyZiF0wP7eU0gMTh-AZShEcbUyP0S2LjhlpKg98W07xN';
          $sound = "default";
    
      // return "success";
      // return $fcm_token;
    if($user_token != null){  
      $registration_ids = [];
      if(!empty($user_token)){            
          $registration_ids = explode(',', $user_token);
      }

      $url = "https://fcm.googleapis.com/fcm/send";
      // $global_order = GlobalOrder::find($global_order_id);
      $data = [
          "registration_ids" => $registration_ids, // Multiple Token
          // 'to' => $fcm_token, // Single
          "notification" => [
              "title" => $title,
              "body" => "Doable",
              "sound" => $sound,
          ],
          "data" => [
              "message" => $n_msg,
          ],
      ];
      $postdata = json_encode($data);
      $header = [
          'Authorization: key=' . $server_key,
          'Content-Type: application/json',
      ];

      $ch = curl_init();
      $timeout = 120;
      curl_setopt($ch, CURLOPT_URL, $url);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
      curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
      curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
      curl_setopt($ch, CURLOPT_HTTPHEADER, $header);

      // Get URL content
      $result = curl_exec($ch);
      if ($result === FALSE) {
        die('FCM Send Error: ' . curl_error($ch));
    }
      curl_close($ch);
  }
     // return $result;


    
    $post = new Notification;
    $post->user_id = $request->id;
    $post->title =  $title;
    $post->description =  $n_msg;
    $post->notify_date = Time::now()->timestamp;
    $post->save();
    return redirect('admin/users')->with('success', 'Sent Notification successfully.');
   
  }
  public function longer_company(Request $request)
  {  
    $user= User::where('id', $request->id)->first();
   
    $user_token=$user->notify_token; // Token generated from Android device after setting up firebase
    $title="Doablewellness";
    $n_msg="Hi, You get No Longer with Company";

   

          //branded
          $server_key="AAAA5EkqgsI:APA91bGMBhH-3EWjx8G1yRgrmEeRwrqTQ1vIDH_LgWlbo2ih2W_yxc70oZS3Rjg-prXEdcn-0xaQh-EqmpqGBuHj6afJ1TPuHmZXWIgZKTz0sal0TceR9UTZcUwOeKdiadhF-WWZAb67"; // get this from Firebase project settings->Cloud Messaging

        //  $push_notification_key = 'AAAABAXk454:APA91bE-yZhQw9fa35mFDSNYp_c4ENcxFZuMD7FHum40vY4JuzQoxNBahvcbXR6B4IdYm065Qrr8Ys9eMXgVHkatgTGZ1PAKOyZiF0wP7eU0gMTh-AZShEcbUyP0S2LjhlpKg98W07xN';
          $sound = "default";
    
      // return "success";
      // return $fcm_token;
    if($user_token != null){  
      $registration_ids = [];
      if(!empty($user_token)){            
          $registration_ids = explode(',', $user_token);
      }

      $url = "https://fcm.googleapis.com/fcm/send";
      // $global_order = GlobalOrder::find($global_order_id);
      $data = [
          "registration_ids" => $registration_ids, // Multiple Token
          // 'to' => $fcm_token, // Single
          "notification" => [
              "title" => $title,
              "body" => "Doable",
              "sound" => $sound,
          ],
          "data" => [
              "message" => $n_msg,
          ],
      ];
      $postdata = json_encode($data);
      $header = [
          'Authorization: key=' . $server_key,
          'Content-Type: application/json',
      ];

      $ch = curl_init();
      $timeout = 120;
      curl_setopt($ch, CURLOPT_URL, $url);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
      curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
      curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
      curl_setopt($ch, CURLOPT_HTTPHEADER, $header);

      // Get URL content
      $result = curl_exec($ch);
      if ($result === FALSE) {
        die('FCM Send Error: ' . curl_error($ch));
    }
      curl_close($ch);
  }
    
    $post = new Notification;
    $post->user_id = $request->id;
    $post->title =  $title;
    $post->description =  $n_msg;
    $post->notify_date = Time::now()->timestamp;
    $post->save();
    return redirect('admin/users')->with('success', 'Sent Notification successfully.');
   
  }
}