<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\category;
use App\Models\youtube_link;
use Storage;
use Carbon\Carbon as Time;
class LinkController extends Controller

{
    public function __construct(){
        $this->middleware('auth');
    }

    public function list(){
        $links = youtube_link::select('tbl_youtube_video_link.*','tbl_category.category_name')
        ->leftJoin('tbl_category', 'tbl_youtube_video_link.category_id', '=', 'tbl_category.id')
        ->where('tbl_youtube_video_link.status_delete','0')
        ->orderBy('tbl_youtube_video_link.id', 'desc')
        ->get();
      // dd(Auth::user()->username);
        return view('Admin.dashboard',[
         'title' => 'Admin Dashboard',
         'page'  => 'dashboard',
         'links'  => $links,

     ]);
 }

    public function add_link(){
        $category = category::where('active_status','1')->get();
    
    
        return view('Admin.add_link',[
          'title' => 'Add Link',
          'category'  => $category,
    
      ]);
      }

   public function edit_link(Request $request){
       // echo $request->id;
        $link = youtube_link::where('id', $request->id)->first();
        $category = category::where('active_status','1')->get();
        return view('Admin.edit_link',[
          'title' => 'Edit Link',
          'category' =>$category,
          'link'  => $link,
    
      ]);
    
      }
      public function view_link(Request $request){
      //  echo $request->id;
        $link = youtube_link::where('id', $request->id)->first();
        $category = category::where('active_status','1')->get();
        return view('Admin.links.view',[
          'title' => 'View Link',
          'category' =>$category,
          'link'  => $link,
    
      ]);
    
      }
 
      public function link_delete($id){
          
           $link = youtube_link::where('id', $id)->first();
          // dd($link);
           $link->status_delete ='0';
           $link->save();
           return redirect('admin/dashboard')->with('success', 'Link Deleted successfully.');
        
      }
  public function create_link(Request $request){
   
   $link =$request->link;
   $video_id = explode("?v=", $link);
   $video_id = $video_id[1];
   $now = Time::now()->timestamp;
   $thumbnail="http://img.youtube.com/vi/".$video_id."/0.jpg";   
   $url = $thumbnail;
   $contents = file_get_contents($url);
   $extension = substr($thumbnail, strrpos($thumbnail, '.') + 1);
   $name = $now.".".$extension;
   Storage::disk('public')->put($name, $contents);

   $linkdb = new youtube_link;
   $linkdb->category_id = $request->category;
   $linkdb->title = $request->link_title;
   $linkdb->description = $request->description;
   $linkdb->thumbnails = $name;
   $linkdb->youtube_link = $request->link;
   $linkdb->active_status = '1';
   $linkdb->save();
   if($linkdb->id){
   return redirect('admin/dashboard')->with('success', 'Link Added successfully.');
   }else{
   return redirect('/login')->with('warning', 'User not applicable.');
  }
 }

  public function update_link(Request $request){
   $linkdb = youtube_link::where('id', $request->id)->first();
   if($linkdb->youtube_link !=$request->link){
     $link =$request->link;
     $video_id = explode("?v=", $link);
     $video_id = $video_id[1];
     $now = Time::now()->timestamp;
     $thumbnail="http://img.youtube.com/vi/".$video_id."/0.jpg";   
     $url = $thumbnail;
     $contents = file_get_contents($url);
     $extension = substr($thumbnail, strrpos($thumbnail, '.') + 1);
     $name = $now.".".$extension;
     Storage::disk('public')->put($name, $contents);
   }else{
     $name = $linkdb->thumbnails;
   }
      

      
       $linkdb->category_id = $request->category;
       $linkdb->title = $request->link_title;
       $linkdb->description = $request->description;
       $linkdb->thumbnails = $name;
       $linkdb->youtube_link = $request->link;
       $linkdb->active_status = '1';
       $linkdb->save();
         if($linkdb->id){
         return redirect('admin/dashboard')->with('success', 'Link Updated successfully.');
         }else{
         return redirect('/login')->with('warning', 'User not applicable.');
       }
  }
}
