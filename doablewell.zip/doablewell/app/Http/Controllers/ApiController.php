<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\category;
use App\Models\youtube_link;

class ApiController extends Controller
{
   

    public function get_youtube_links(Request $request){
        $validator = Validator::make($request->only('token'), [
            'token' => 'required'
        ]);
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => $validator->messages(),
            ],200);
        }
        $category = category::where('active_status',1)->get();
         foreach($category as $cate){
            $cate->get_link = youtube_link::where('category_id', $cate->id)->get();
            
         }
        return response()->json(['category' => $category]);
    }


}
