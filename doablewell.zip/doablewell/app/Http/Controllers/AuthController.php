<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Lang;
use App\Models\User;
use App\Models\Notification;
use JWTAuth;
use \Firebase\JWT\JWT;
use Illuminate\Support\Facades\Crypt;
use Tymon\JWTAuth\Exceptions\JWTException;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Validator;
use Mail;

class AuthController extends Controller
{
    private $GeneraKey = "qhgCxWp2us";
    

    public function register(Request $request)
    {
    	//Validate data
        $data = $request->only('name', 'email', 'password','company_name');
        
        $validator = Validator::make( $data , [ 
            'name' => 'required|string',
           // 'notify_token' => 'required',
            'company_name' => 'required|string',
            'email' => 'required|email|unique:users',
            'password' => 'required|string|min:6|max:50', 
        ],
        [
            'name.required' => 'required username',
           // 'notify_token.required' => 'required Notification token',
            'company_name.required' => 'required company name',
            'email.required' => 'required email',
            'email.email'     => 'Please enter valid email',
            'email.unique'     => 'Email already exist',
            'password.required' =>  'required password',
        ]
    );
        if ($validator->fails()) {
            $messages = $validator->messages();
            foreach ($messages->all() as $message)
            {   
                return response()->json(['success'=>false,'message'=>$message]);            
            }
        }

        //Send failed response if request is not valid
        if ($validator->fails()) {

            return response()->json([
                'success' => false,
                'message' => $validator->messages(),
            ],200);
            // return response()->json(['error' => $validator->messages()], 200);
        }

        //Request is valid, create new user
        
        $user = User::create([
        	'username' => $request->name,
        	'company_name' => $request->company_name,
        	'email' => $request->email,
        	'password' => bcrypt($request->password),
            'user_role' => "2",
            'user_verified' =>'1',
            'notify_token' => $request->notify_token ?: 'null',
        ]);
        $credentials = $request->only('email', 'password');
        try {
            if (! $token = JWTAuth::attempt($credentials)) {
                return response()->json([
                	'success' => false,
                	'message' => 'Login credentials are invalid.',
                ], 200);
            }
        } catch (JWTException $e) {
    	return $credentials;
            return response()->json([
                	'success' => false,
                	'message' => 'Could not create token.',
                ], 200);
        }
        return response()->json([
            'success' => true,
            'token' => $token,
        ]);
        //User created, return success response
        // return response()->json([
        //     'success' => true,
        //     'message' => 'User created successfully',
        //     'data' => $user
        // ], Response::HTTP_OK);
    }
 
    public function login(Request $request)
    {
        $credentials = $request->only('email', 'password','notify_token');

        $validator = Validator::make( $credentials , [ 
          
            'email' => 'required|email',
            'password' => 'required', 
           
        ],
        [
        
            'email.required' => 'required email',
            'email.email'     => 'Please enter valid email',           
            'password.required' =>  'required password',
            
        ]
    );
        if ($validator->fails()) {
            $messages = $validator->messages();
            foreach ($messages->all() as $message)
            {   
                return response()->json(['success'=>false,'message'=>$message]);            
            }
        }

        $data = $request->only('email', 'password');
        //Request is validated
        //Crean token
        try {
            if (! $token = JWTAuth::attempt($data)) {
                return response()->json([
                	'success' => false,
                	'message' => 'Login credentials are invalid.',
                ], 200);
            }
        } catch (JWTException $e) {
    	return $credentials;
            return response()->json([
                	'success' => false,
                	'message' => 'Could not create token.',
                ], 200);
        }
 	
 		//Token created, return with success response and jwt token
         $user = User::where('email',$request->email)->first();
            
             if($user != null){            
                $user->notify_token=   $request->notify_token ?: '';
                $user->save();   
             }
        return response()->json([
            'success' => true,
            'token' => $token,
        ]);
    }

    public function logout(Request $request)
    {
        //valid credential
        $validator = Validator::make($request->only('token'), [
            'token' => 'required'
        ]);

        //Send failed response if request is not valid
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => $validator->messages(),
            ],200);
        }

		//Request is validated, do logout        
        try {
            JWTAuth::invalidate($request->token);
 
            return response()->json([
                'success' => true,
                'message' => 'User has been logged out'
            ]);
        } catch (JWTException $exception) {
            return response()->json([
                'success' => false,
                'message' => 'Sorry, user cannot be logged out'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }

        
    }

    public function update_profile(Request $request){
         //Validate data
         $validator = Validator::make($request->only('token'), [
            'token' => 'required'
        ]);

        //Send failed response if request is not valid
        if ($validator->fails()) {
            return response()->json(['error' => $validator->messages()], 200);
        }
 
         //Request is valid, update product
         $user = User::where('id', JWTAuth::user()->id)->first();
        // echo Crypt::decryptString($Getuser->password); die();

         $HashedPass = $user->password;
         
        
         if(Hash::check($request->old_password, $HashedPass))   
         {
            
             if( $request->confirm_password == $request->password){
             $user->username= $request->username;
             $user->password = bcrypt($request->password);
             $user->save();
             }
             else
             {
                 return response()->json([
                     'success' => false,
                     'message' => 'confirm password and password not match.',
                 ], 200);
             }
         }
         else
            {
                return response()->json([
                	'success' => false,
                	'message' => 'current password is wrong',
                ], 200);
            }
         //Product updated, return success response
         return response()->json([
             'success' => true,
             'message' => 'Profile updated successfully',
             'data' => $user
         ], Response::HTTP_OK);
    }

    public function get_user(Request $request)
    {
        $validator = Validator::make($request->only('token'), [
            'token' => 'required'
        ]);
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => $validator->messages(),
            ],200);
        }
 
        $user = JWTAuth::authenticate($request->token);
 
        return response()->json(['user' => $user]);
    }

    public function test(){
        $user = JWTAuth::user()->username;
        return ['message'=> $user];
    }


    public function forgot_password(Request $request){

        $credentials = $request->only('email');

        $validator = Validator::make( $credentials , [ 
          
            'email' => 'required|email', 
        ],
        [
        
            'email.required' => 'email address is required',
            'email.email'     => 'Please enter valid email'
        ]
    );

    if ($validator->fails()) {
        $messages = $validator->messages();
        foreach ($messages->all() as $message)
        {   
            return response()->json(['success'=>false,'message'=>$message]);            
        }
    }
      
        $otp = mt_rand(1000,9999);
             $user = User::where('email',$request->email)->first();
            
             if($user != null){
               
            
                $user->otp_verify=  $otp;
                $user->save();          
            
                $data = array('name'=>"Doable Wellness Forgot Password",'otp'=> $otp);
                $email= $request->email;
                Mail::send('emailOtp', $data, function($message) use ($email){
                    
                $message->to($email ,'doablewellness')->subject
                    ('Doable Wellness Forgot Password');
                $message->from('megha.singh@zibtek.in','Doable Wellness');
                });
                return response()->json([
                    'success' => true,
                    'message' => 'The otp Sent given your Email address',
                ], Response::HTTP_OK);
        }else{
            return response()->json([
                'success' => false,
                'message' => 'Email Not Register please give another email',
            ], 200);
        }
    } 

    public function otp_verify(Request $request){

        $credentials = $request->only('email','otp');

        $validator = Validator::make( $credentials , [ 
           'otp' => 'required',
            'email' => 'required|email', 
        ],
        [
        
            'otp.required' => 'OTP is required',
            'email.required' => 'email address is required',
            'email.email'     => 'Please enter valid email'
        ]
    );

                if ($validator->fails()) {
                    $messages = $validator->messages();
                    foreach ($messages->all() as $message)
                    {   
                        return response()->json(['success'=>false,'message'=>$message]);            
                    }
                }
      
       
             $user = User::where('email', $request->email)->first();
            // dd($user);
             if($user != null){
            
             if($user->otp_verify == $request->otp){
                $user->user_verified= '1';
                $user->save();
                return response()->json([
                    'success' => true,
                    'message' => 'Otp Verified',
                ], Response::HTTP_OK);
             }else{
                return response()->json([
                    'success' => false,
                    'message' => 'Otp Not Matched Please Try Again',
                ], 200);
             }
             }else{
                return response()->json([
                    'success' => false,
                    'message' => 'Email Not Register please give another email',
                ], 200);
             }
       
        
    } 


    public function reset_password(Request $request){
        //Validate data
        $credentials = $request->only('email');

        $validator = Validator::make( $credentials , [ 
          
            'email' => 'required|email', 
        ],
        [
        
            'email.required' => 'email address is required',
            'email.email'     => 'Please enter valid email'
        ]
    );
       //Send failed response if request is not valid
       if ($validator->fails()) {
           return response()->json(['error' => $validator->messages()], 200);
       }

        //Request is valid, update product
        $user = User::where('email', $request->email)->first();
       // echo Crypt::decryptString($Getuser->password); die();
       if($user != null){
        $HashedPass = $user->password;     
      
           if($user->user_verified == 1){           
            if( $request->confirm_password == $request->password){
            $user->password = bcrypt($request->password);
            $user->save();
            }
            else
            {
                return response()->json([
                    'success' => false,
                    'message' => 'confirm password and password not match.',
                ], 200);
            }
        }  else{
            return response()->json([
                'success' => false,
                'message' => 'User not verified please try again',
            ], 200);
        }
        //Product updated, return success response
        return response()->json([
            'success' => true,
            'message' => 'Password Reset successfully',
        ], Response::HTTP_OK);
    }else{
        return response()->json([
            'success' => false,
            'message' => 'Email Not Register please give another email',
        ], 200);
    }
   }
   public function reword_request(Request $request){

    $validator = Validator::make($request->only('token'), [
        'token' => 'required'
    ]);

    //Send failed response if request is not valid
    if ($validator->fails()) {
        return response()->json(['error' => $validator->messages()], 200);
    }

     //Request is valid, update product
     $user = User::where('id', JWTAuth::user()->id)->first();

        
         if($user != null){
           
        
           $username = $user->username;
          
            $data = array('name'=>"Doable Wellness Reword Request",'username'=> $username);
            $email= $request->email;
            Mail::send('reword_request', $data, function($message) use ($email){
                
            $message->to("megha.singh@zibtek.in" ,'doablewellness')->subject
                ('Doable Wellness Reword Request');
            $message->from('megha.singh@zibtek.in','Doable Wellness');
            });
            return response()->json([
                'success' => true,
                'message' => 'The Request Admin for Reword ',
            ], Response::HTTP_OK);
    }else{
        return response()->json([
            'success' => false,
            'message' => 'Email Not Register please give another email',
        ], 200);
    }
} 

public function get_notification(Request $request)
{
    $validator = Validator::make($request->only('token'), [
        'token' => 'required'
    ]);

    //Send failed response if request is not valid
    if ($validator->fails()) {
        return response()->json(['error' => $validator->messages()], 200);
    }

     //Request is valid, update product
     $notification = Notification::where('user_id' ,JWTAuth::user()->id)->orderBy('id', 'desc')->get()->toArray();
     //  dd($notification);
         if($notification != []){
            return response()->json([
                'success' => true,
                'message' => 'Data found succesfully',
                'notification' => $notification
            ], Response::HTTP_OK);
         }else{
            return response()->json([
                'success' => false,
                'message' => 'Data not found',
            ], 200);
         }
}

    public function me()
    {
        return response()->json(auth()->user());
    }

    /**
     * Log the user out (Invalidate the token).
     *
     * @return \Illuminate\Http\JsonResponse
     */
    // public function logout()
    // {
    //     auth()->logout();

    //     return response()->json(['message' => 'Successfully logged out']);
    // }

    public function refresh()
    {
        return $this->respondWithToken(auth()->refresh());
    }
    
    protected function respondWithToken($token)
    {
        return response()->json([
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => auth()->factory()->getTTL() * 60
        ]);
    }

  
}
