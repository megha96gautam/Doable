<!DOCTYPE html>
<html lang="en">
@include('layouts.head')
<link href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css" rel="stylesheet"/>
<body>

@include('layouts.nav')

<div class="container" style="width: 65%;"><br>
<h2>{{ $title }}</h2>
<form method="POST" action="{{ url('admin/update_user') }}">
  @csrf
  <div class="form-row">
      <input type="hidden" value="{{ $user->id }}" name="id" />
    <div class="form-group col-md-12">
    <label for="inputPassword4">Username</label>
      <input type="text" class="form-control" name="username" value="{{ $user->username}}" >
    </div>
    <div class="form-group col-md-12">
      <label for="inputPassword4">company name</label>
      <input type="text" class="form-control" name="company_name" value="{{ $user->company_name}}" >
    </div>
  </div>
  <div class="form-group col-md-12">
    <label for="inputAddress">Email</label>
    <input type="text" class="form-control" name="email" readonly value="{{ $user->email }}">
  </div>
  
  
  
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>