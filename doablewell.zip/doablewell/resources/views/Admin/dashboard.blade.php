<!DOCTYPE html>
<html lang="en">
@include('layouts.head')
<link href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css" rel="stylesheet"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<body>

@include('layouts.nav')
<div  style="width: 95%;margin-bottom:70px">
<a type="button" href="{{ url('admin/add_link') }}" class="btn btn-info" style="float:right;">Add link</a>
</div>
<div class="container" style="width: 95%;"><br>
@if(Session::has('success'))

<div class="alert alert-success" style="color: #8ec48e;">{{Session::get('success')}}</div>

@endif

@if(Session::has('warning'))

<div class="alert alert-danger">{{Session::get('warning')}}</div>

@endif
<div class="col-lg-12">
<table id="example" style="    margin-top: 80px;" class="display" style="width:100%">
        <thead>
            <tr>
                <th>SNo.</th>
                <th>Slider Group</th>
                <th>Title</th>
                <th>Youtube Link</th>
                <th>Text</th>
                <th>Thumbnails</th>
                <th>create_at</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
          @php   $i= 1; @endphp
        @foreach( $links as $link )
            <tr>
                <td><?php echo $i++; ?></td>
                <td>{{ $link->category_id }}</td>
                <td>{{ $link->title }}</td>
                <td>{{ $link->youtube_link }}</td>
                <td>{{ $link->description }}</td>
                <td><img width="100px" height="100px" src="{{ url('youtube_img') }}/{{ $link->thumbnails }}" /> </td>
                <td>{{ $link->created_at }}</td>
                <td>
                    <a type="button" class="btn btn-warning" href="{{ url('admin/view_link/'.$link->id) }}" ><i class="fa fa-reply" style="font-size:12px"></i></a>
                 
                    <a type="button" class="btn btn-info" href="{{ url('admin/edit_link/'.$link->id) }}">
                        <i class="fa fa-edit" style="font-size:12px"></i></a> 
                    <a  type="button" onclick="return confirm('Are you sure you want to delete this link?');" class="btn btn-danger" href="{{ url('admin/link_delete/'.$link->id) }}"><i class="fa fa-trash-o" style="font-size:12px"></i></a>
                   
                </td>
            </tr>
       @endforeach
          
        </tbody>
        <!-- <tfoot>
            <tr>
                <th>Name</th>
                <th>Position</th>
                <th>Office</th>
                <th>Age</th>
                <th>Start date</th>
                <th>Salary</th>
            </tr>
        </tfoot> -->
    </table>
</div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script>
  $(document).ready(function() {
    $('#example').DataTable();
} );
</script>