<!DOCTYPE html>
<html lang="en">
@include('layouts.head')
<link href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css" rel="stylesheet"/>
<body>

@include('layouts.nav')

<div class="container" style="width: 65%;"><br>
<h2>{{ $title }}</h2>
<form method="POST" action="#">
  @csrf
  <div class="form-row">
      <input type="hidden" value="{{ $link->id }}" name="id" />
    <div class="form-group col-md-12">
      <label for="inputEmail4">Title</label>
     
      <input class="form-control" value="{{ $link->title }}" name="category">
       
    </div>
    <div class="form-group col-md-12">
      <label for="inputPassword4">youtube_link</label>
      <input type="text" class="form-control" name="link_title" value="{{ $link->youtube_link}}" >
    </div>
  </div>
  <div class="form-group col-md-12">
    <label for="inputAddress">Description</label>
    <input type="text" class="form-control" name="description" value="{{ $link->description }}"/>
  </div>

  
  
  <!-- <button type="submit" class="btn btn-primary">Submit</button> -->
</form>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>