<!DOCTYPE html>
<html lang="en">
@include('layouts.head')
<link href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css" rel="stylesheet"/>
<body>

@include('layouts.nav')

<div class="container" style="width: 65%;"><br>
<h2>{{ $title }}</h2>
@if(Session::has('success'))

<div class="alert alert-success" style="color: #8ec48e;">{{Session::get('success')}}</div>

@endif

@if(Session::has('warning'))

<div class="alert alert-danger">{{Session::get('warning')}}</div>

@endif
<form method="POST" action="{{ url('admin/update_password') }}">
  @csrf
  <div class="form-row">
    
    <div class="form-group col-md-12">
    <label for="inputPassword4">Old Password</label>
      <input type="password" class="form-control" name="old_pass" required>
    </div>
    <div class="form-group col-md-12">
      <label for="inputPassword4">New password</label>
      <input type="password" class="form-control" name="new_pass" required>
    </div>
  </div>
  <div class="form-group col-md-12">
    <label for="inputAddress">Confirm Password</label>
    <input type="password" class="form-control" name="confm_pass" required>
  </div> 
  
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>