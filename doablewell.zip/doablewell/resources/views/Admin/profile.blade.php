<!DOCTYPE html>
<html lang="en">
@include('layouts.head')
<link href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css" rel="stylesheet"/>
<body>

@include('layouts.nav')

<div class="container" style="width: 65%;"><br>
<h2>{{ $title }}</h2>
@if(Session::has('success'))

<div class="alert alert-success" style="color: #8ec48e;">{{Session::get('success')}}</div>

@endif

@if(Session::has('warning'))

<div class="alert alert-danger">{{Session::get('warning')}}</div>

@endif
<form method="POST" action="{{ url('admin/update_profile') }}">
  @csrf
  <div class="form-row">
      <input type="hidden" value=" {{ Auth::user()->id }}" name="id" />
    <div class="form-group col-md-12">
    <label for="inputPassword4">Username</label>
      <input type="text" class="form-control" name="username" value=" {{ Auth::user()->username }}" >
    </div>
    <div class="form-group col-md-12">
      <label for="inputPassword4">company name</label>
      <input type="text" class="form-control" name="company_name" value=" {{ Auth::user()->company_name }}" >
    </div>
  </div>
  <div class="form-group col-md-12">
    <label for="inputAddress">Email</label>
    <input type="text" class="form-control" name="email" readonly value=" {{ Auth::user()->email }}">
  </div>
  
  
  
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>