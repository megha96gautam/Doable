<!DOCTYPE html>
<html lang="en">
@include('layouts.head')
<link href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css" rel="stylesheet"/>
<body>

@include('layouts.nav')

<div class="container" style="width: 65%;"><br>
<h2>{{ $title }}</h2>
<form method="POST" action="{{ url('admin/update_link') }}">
  @csrf
  <div class="form-row">
      <input type="hidden" value="{{ $link->id }}" name="id" />
    <div class="form-group col-md-12">
      <label for="inputEmail4">category</label>
     
      <select class="form-control" id="" name="category">
         <option value="{{ $link->category_id }}">Select category</option>
         @foreach($category as $cat)
         <option value="{{ $cat->id }}">{{ $cat->category_name }}</option>
         @endforeach
      </select>
    </div>
    <div class="form-group col-md-12">
      <label for="inputPassword4">Title</label>
      <input type="text" class="form-control" name="link_title" value="{{ $link->title}}" >
    </div>
  </div>
  <div class="form-group col-md-12">
    <label for="inputAddress">Description</label>
    <textarea type="text" class="form-control" name="description" id="inputAddress">{{ $link->description}}</textarea>
  </div>
  <div class="form-group col-md-12">
    <label for="inputAddress2">Youtube Link</label>
    <input type="text" class="form-control" id="inputAddress2" name="link" value="{{ $link->youtube_link }}">
  </div>
  
  
  <!-- <button type="submit" class="btn btn-primary">Submit</button> -->
</form>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>