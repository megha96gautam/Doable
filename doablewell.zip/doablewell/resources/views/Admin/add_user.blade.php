<!DOCTYPE html>
<html lang="en">
@include('layouts.head')
<link href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css" rel="stylesheet"/>
<body>

@include('layouts.nav')

<div class="container" style="width: 65%;"><br>
<h2>{{ $title }}</h2>
<form method="POST" action="{{ url('admin/create_user') }}">
  @csrf
  <div class="form-row">
    <div class="form-group col-md-12">
      <label for="inputEmail4">Username</label>
      <input type="text" class="form-control" id="username"  name="username" placeholder="Username"  required>
    </div>
    <div class="form-group col-md-12">
      <label for="inputPassword4">Email</label>
      <input  class="form-control" id="email" type="email" name="email" placeholder="mail@example.com" onblur="checkmain(this.value)" required>
      <span style="color:red;" id="msg"></span>
    </div>
  </div>
  <div class="form-group col-md-12">
    <label for="inputAddress">Company Name</label>
    <input type="text" class="form-control" name="company_name" id="company_name" >
  </div>
  <div class="form-group col-md-12">
    <label for="inputAddress2">Password</label>
    <input type="password" class="form-control" id="password" name="password">
  </div>
  
  <div class="form-group col-md-12">
  <input type="submit" class="btn btn-primary" value="Submit" />
</div>
</form>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script>
    function checkmain(email)
{
$.ajax({
    url: '{{url('admin/checkemail')}}',
type: 'POST',
data: { "_token": "{{ csrf_token() }}", email: email },
}).done(function(response) {
if(response == "Email Already In Use.")
{
    $("#msg").html("Email Already exist");
    $(':input[type="submit"]').prop('disabled', true);
}
});
}
</script>