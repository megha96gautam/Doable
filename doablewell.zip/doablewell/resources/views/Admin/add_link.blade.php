<!DOCTYPE html>
<html lang="en">
@include('layouts.head')
<link href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css" rel="stylesheet"/>
<body>

@include('layouts.nav')

<div class="container" style="width: 65%;"><br>
<h2>{{ $title }}</h2>
<form method="POST" action="{{ url('admin/create_link') }}">
  @csrf
  <div class="form-row">
    <div class="form-group col-md-12">
      <label for="inputEmail4">Category</label>
     
      <select class="form-control" id="" name="category" required>
         <option>Select category</option>
         @foreach($category as $cat)
         <option value="{{ $cat->id }}">{{ $cat->category_name }}</option>
         @endforeach
      </select>
    </div>
    <div class="form-group col-md-12">
      <label for="inputPassword4">Title</label>
      <input type="text" class="form-control" name="link_title" id="inputPassword4" required>
    </div>
  </div>
  <div class="form-group col-md-12">
    <label for="inputAddress">Description</label>
    <textarea type="text" class="form-control" name="description" id="inputAddress" ></textarea>
  </div>
  <div class="form-group col-md-12">
    <label for="inputAddress2">Youtube Link</label>
    <input type="text" class="form-control" id="inputAddress2" name="link">
  </div>
  
  <div class="form-group col-md-12">
  <button type="submit" class="btn btn-primary">Submit</button>
</div>
</form>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>