<style>
  .float-right{
    float:right;
  }
</style>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="{{ url('admin/users') }}">Doable Wellness</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="{{ (Request::segment(2) == 'users' ) ? 'active' : '' }}"><a href="{{ url('admin/users') }}">User List</a></li>
      <li class="{{ (Request::segment(2) == 'category' ) ? 'active' : '' }}"><a href="{{ url('admin/category') }}">Category List</a></li>
      <li class="{{ (Request::segment(2) == 'dashboard' ) ? 'active' : '' }}"><a href="{{ url('admin/dashboard') }}">Youtube Link List</a></li>
      <li class="{{ (Request::segment(2) == 'profile' ) ? 'active' : '' }}"><a href="{{ url('admin/profile') }}">Profile</a></li>
      <li class="{{ (Request::segment(2) == 'reset_password' ) ? 'active' : '' }}"><a href="{{ url('admin/reset_password') }}">Reset Password</a></li>
     
    </ul>
    <ul class="nav navbar-nav" style="float:right">
    <li class="nav-item dropdown"  >
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        {{ Auth::user()->username }}
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="{{ url('admin/logout')}}">Logout</a>
        
        </div>
      </li>
    </ul>
  
   
  </div>
</nav>