<!DOCTYPE html>
<html>
<head>
   
</head>
<body>
   
   
    <p>Hi </p>
    <p>Your Doablewellness forgot password otp is {{ $otp }}.</p>
</body>
</html>