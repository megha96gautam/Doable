<!DOCTYPE html>
<html>
<head>
   
</head>
<body>
   
   
    <p>Hi Admin</p>
    <p>This {{ $username }} send reword request please proceed for reword points.</p>
</body>
</html>