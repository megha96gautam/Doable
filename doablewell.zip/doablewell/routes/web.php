<?php

use Illuminate\Support\Facades\Route;
use App\Http\Middleware\Admin;
use Illuminate\Contracts\Auth\Access\Gate;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
});

Auth::routes();

Route::get('/login', [App\Http\Controllers\Auth\LoginController::class, 'index']);
route::post('adminlogin',[App\Http\Controllers\Auth\LoginController::class, 'login']);
// Route::Auth();
Route::group(['middleware' => 'admin','prefix'=>'admin'], function () {
 // Route::auth();
route::get('/dashboard',[App\Http\Controllers\DashboardController::class, 'dashboard'])->name('dashboard');
route::get('/users',[App\Http\Controllers\DashboardController::class, 'user_list'])->name('user_list');
route::get('/category',[App\Http\Controllers\CategoryController::class, 'category_list'])->name('user_list');
route::get('/add_link',[App\Http\Controllers\LinkController::class, 'add_link']);
route::get('/add_user',[App\Http\Controllers\UserController::class, 'add_user']);
route::get('/add_category',[App\Http\Controllers\CategoryController::class, 'add_category']);
route::post('/checkemail',[App\Http\Controllers\UserController::class, 'checkemail']);
route::get('/edit_link/{id}',[App\Http\Controllers\LinkController::class, 'edit_link']);
route::get('/edit_category/{id}',[App\Http\Controllers\CategoryController::class, 'edit_category']);
route::get('/edit_user/{id}',[App\Http\Controllers\UserController::class, 'edit_user']);
route::get('/view_link/{id}',[App\Http\Controllers\LinkController::class, 'view_link']);
route::get('/view_user/{id}',[App\Http\Controllers\UserController::class, 'view_user']);
route::get('/view_category/{id}',[App\Http\Controllers\CategoryController::class, 'view_category']);
Route::get('/link_delete/{id}', [App\Http\Controllers\LinkController::class,'link_delete'])->name('link.destroy');
Route::get('/user_delete/{id}', [App\Http\Controllers\UserController::class,'delete']);
Route::get('/category_delete/{id}', [App\Http\Controllers\CategoryController::class,'category_delete']);
Route::get('/send_notification/{id}', [App\Http\Controllers\UserController::class,'send_notification']);
Route::get('/claimpoints/{id}', [App\Http\Controllers\UserController::class,'claimpoints']);
Route::get('/longer_company/{id}', [App\Http\Controllers\UserController::class,'longer_company']);
Route::get('/profile', [App\Http\Controllers\DashboardController::class,'profile']);
Route::get('/reset_password', [App\Http\Controllers\DashboardController::class,'reset_password']);
route::post('/create_link',[App\Http\Controllers\LinkController::class, 'create_link']);
route::post('/create_user',[App\Http\Controllers\UserController::class, 'create_user']);
route::post('/submit_category',[App\Http\Controllers\CategoryController::class, 'submit_category']);
route::post('/update_link',[App\Http\Controllers\LinkController::class, 'update_link']);
route::post('/update_category',[App\Http\Controllers\CategoryController::class, 'update_category']);
route::post('/update_user',[App\Http\Controllers\UserController::class, 'update_user']);
route::post('/update_profile',[App\Http\Controllers\DashboardController::class, 'update_profile']);
route::post('/update_password',[App\Http\Controllers\DashboardController::class, 'update_password']);
route::get('/logout',[App\Http\Controllers\Auth\LoginController::class, 'logout']);

});



