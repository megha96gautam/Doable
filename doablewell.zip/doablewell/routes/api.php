<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\ApiController;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::post('login', [AuthController::class, 'login']);
// Route::post('authlogin', [AuthController::class, 'authenticate']);
    Route::post('register', [AuthController::class, 'register']);
    Route::get('send_mail', [AuthController::class, 'send_mail']);
    Route::post('forgot_password', [AuthController::class, 'forgot_password']);
    
    Route::post('otp_verify', [AuthController::class, 'otp_verify']);
    Route::post('reset_password', [AuthController::class, 'reset_password']);

Route::group(['middleware' => ['jwt.verify']], function() {
    Route::post('/get_user', [AuthController::class, 'get_user']);
    Route::put('/update_profile', [AuthController::class, 'update_profile']);
    Route::get('logout', [AuthController::class, 'logout']);
    Route::post('reword_request', [AuthController::class, 'reword_request']);
    Route::post('get_links', [ApiController::class, 'get_youtube_links']);
    Route::post('notifications', [AuthController::class, 'get_notification']);
 
    
});